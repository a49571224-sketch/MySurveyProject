import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'تطبيق مسح الشبكات',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
      ),
      home: SurveyMapScreen(),
    );
  }
}

class SurveyMapScreen extends StatefulWidget {
  @override
  _SurveyMapScreenState createState() => _SurveyMapScreenState();
}

class _SurveyMapScreenState extends State<SurveyMapScreen> {
  final List<Marker> _markers = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('تطبيق مسح الشبكات (أوفلاين)'),
        backgroundColor: Colors.blueGrey,
      ),
      body: FlutterMap(
        options: MapOptions(
          initialCenter: LatLng(15.3694, 44.1910), 
          initialZoom: 15.0,
          onTap: (tapPosition, point) {
            _addNewAssetMarker(point);
          },
        ),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.example.survey_app',
          ),
          MarkerLayer(
            markers: _markers,
          ),
        ],
      ),
    );
  }

  void _addNewAssetMarker(LatLng point) {
    setState(() {
      _markers.add(
        Marker(
          point: point,
          width: 40.0,
          height: 40.0,
          child: GestureDetector(
            onTap: () {
              print("تم النقر على الموقع: ${point.latitude}, ${point.longitude}");
            },
            child: Icon(
              Icons.location_pin,
              color: Colors.red,
              size: 40,
            ),
          ),
        ),
      );
    });
  }
}
